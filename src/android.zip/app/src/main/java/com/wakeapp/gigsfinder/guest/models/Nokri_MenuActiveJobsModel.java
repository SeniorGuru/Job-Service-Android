package com.wakeapp.gigsfinder.guest.models;

public class Nokri_MenuActiveJobsModel {

    private String resumeReceived;
    private String delete;
    private String edit;
    private String viewJob;

    public String getResumeReceived() {
        return resumeReceived;
    }

    public void setResumeReceived(String resumeReceived) {
        this.resumeReceived = resumeReceived;
    }

    public String getDelete() {
        return delete;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }

    public String getEdit() {
        return edit;
    }

    public void setEdit(String edit) {
        this.edit = edit;
    }

    public String getViewJob() {
        return viewJob;
    }

    public void setViewJob(String viewJob) {
        this.viewJob = viewJob;
    }
}
