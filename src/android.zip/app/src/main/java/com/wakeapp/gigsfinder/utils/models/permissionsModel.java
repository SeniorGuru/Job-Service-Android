package com.wakeapp.gigsfinder.utils.models;

public class permissionsModel {
    private String title;
    private String desc;
    private String btn_goTo;
    private String btnCancel;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getBtn_goTo() {
        return btn_goTo;
    }

    public void setBtn_goTo(String btn_goTo) {
        this.btn_goTo = btn_goTo;
    }

    public String getBtnCancel() {
        return btnCancel;
    }

    public void setBtnCancel(String btnCancel) {
        this.btnCancel = btnCancel;
    }
}
