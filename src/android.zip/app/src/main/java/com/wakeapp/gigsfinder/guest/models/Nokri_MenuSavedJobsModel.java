package com.wakeapp.gigsfinder.guest.models;

public class Nokri_MenuSavedJobsModel {
    private String viewJob;
    private String deleteJob;

    public String getViewJob() {
        return viewJob;
    }

    public void setViewJob(String viewJob) {
        this.viewJob = viewJob;
    }

    public String getDeleteJob() {
        return deleteJob;
    }

    public void setDeleteJob(String deleteJob) {
        this.deleteJob = deleteJob;
    }
}
